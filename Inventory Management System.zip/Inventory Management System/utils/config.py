# Configuration for email alerts and user credentials
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_PORT = 587
EMAIL_ADDRESS = 'guffrana.anjum@gmail.com'
EMAIL_PASSWORD = 'gwdv nkdr ftdu sysg'

USERS = {
    "admin": {"password": "Password", "role": "Admin"},
    "user": {"password": "Newuser", "role": "User"}
}
