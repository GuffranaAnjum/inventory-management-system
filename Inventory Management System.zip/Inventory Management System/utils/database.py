from threading import Lock

class Database:
    def __init__(self):
        self.items = [
            {"id": 1, "name": "tops", "stock": 150, "cost_of_goods_sold": 9000, "historical_sales": 3500},
            {"id": 2, "name": "jeans", "stock": 100, "cost_of_goods_sold": 5500, "historical_sales": 500},
            {"id": 3, "name": "kurti", "stock": 40, "cost_of_goods_sold": 9000, "historical_sales": 1000},
            {"id": 4, "name": "pants", "stock": 100, "cost_of_goods_sold": 10000, "historical_sales": 4000},
            {"id": 5, "name": "palazoo", "stock": 80, "cost_of_goods_sold": 3000, "historical_sales": 7000},
            {"id": 6, "name": "shirts", "stock": 20, "cost_of_goods_sold": 2000, "historical_sales": 1500},
        ]
        
        self.locks = {item['id']: Lock() for item in self.items}

    def lock_item(self, item_id):
        return self.locks[item_id]

    def update_item(self, item_id, quantity):
        for item in self.items:
            if item['id'] == item_id:
                item['stock'] += quantity
                print(f"Updated {item['name']} stock to {item['stock']}")

    def add_item(self, item_id, name, stock, cost_of_goods_sold, historical_sales):
        new_item = {
            "id": item_id,
            "name": name,
            "stock": stock,
            "cost_of_goods_sold": cost_of_goods_sold,
            "historical_sales": historical_sales
        }
        self.items.append(new_item)
        self.locks[item_id] = Lock()

    def get_all_items(self):
        return self.items
